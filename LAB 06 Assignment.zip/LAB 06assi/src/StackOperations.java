import java.util.Stack;

public class StackOperations {

    public static String reverseString(String str) {
        Stack<Character> stack = new Stack<>();
        for (int i = 0; i < str.length(); i++) {
            stack.push(str.charAt(i));
        }
        StringBuilder reversedString = new StringBuilder();
        while (!stack.isEmpty()) {
            reversedString.append(stack.pop());
        }
        return reversedString.toString();
    }

    public static int reverseNumber(int num) {
        Stack<Integer> stack = new Stack<>();
        while (num > 0) {
            stack.push(num % 10);
            num = num / 10;
        }
        int reversedNumber = 0;
        int placeValue = 1;
        while (!stack.isEmpty()) {
            reversedNumber += stack.pop() * placeValue;
            placeValue *= 10;
        }
        return reversedNumber;
    }

    public static int searchElement(Stack<Integer> stack, int element) {
        Stack<Integer> tempStack = new Stack<>();
        int position = -1;
        int index = 1;
        while (!stack.isEmpty()) {
            int top = stack.pop();
            tempStack.push(top);
            if (top == element) {
                position = index;
            }
            index++;
        }
        while (!tempStack.isEmpty()) {
            stack.push(tempStack.pop());
        }
        return position;
    }

    public static int peek(Stack<Integer> stack) {
        if (!stack.isEmpty()) {
            return stack.peek();
        } else {
            return -1;
        }
    }

    public static void main(String[] args) {
        String str = "HelloWorld";
        System.out.println("Reversed String: " + reverseString(str));

        int num = 12345;
        System.out.println("Reversed Number: " + reverseNumber(num));

        Stack<Integer> stack = new Stack<>();
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        stack.push(50);
        System.out.println("Position of element 30: " + searchElement(stack, 30));

        System.out.println("Top element of the stack: " + peek(stack));
    }
}

