public class Main {
    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();
        list.addNode(1);
        list.addNode(2);
        list.addNode(3);
        list.addNode(4);
        list.addNode(5);
        list.printList();
        System.out.println("Length: " + list.getLength());
        System.out.println("Middle Node: " + list.getMiddle().data);
        SinglyLinkedList reversedList = list.reverse();
        reversedList.printList();
        list.addNode(5);
        list.addNode(5);
        list.removeDuplicates();
        list.printList();
        SinglyLinkedList list2 = new SinglyLinkedList();
        list2.addNode(2);
        list2.addNode(4);
        list2.addNode(6);
        SinglyLinkedList mergedList = SinglyLinkedList.mergeSorted(list, list2);
        mergedList.printList();
        list.deleteAll();
        list.printList();
    }
}